/*
    Stackbit Vanilla Theme
    This is where your custom site code goes.
    This script will be loaded on all pages and posts.
 */